package pocketmod;

import net.minecraft.item.ItemStack;
import net.minecraftforge.oredict.OreDictionary;

// Слитком считается любой предмет с именем в словаре руд, начинающимся с "ingot"
// (железный, золотой, кирпич и слитки из других модов).
public class Ingots {

    public static String ingotName(ItemStack stack) {
        if (stack.isEmpty()) {
            return null;
        }
        for (int id : OreDictionary.getOreIDs(stack)) {
            String name = OreDictionary.getOreName(id);
            if (name.startsWith("ingot")) {
                return name;
            }
        }
        return null;
    }

    public static boolean isIngot(ItemStack stack) {
        return ingotName(stack) != null;
    }

    // Сколько маны даёт один слиток
    public static int manaValue(ItemStack stack) {
        String name = ingotName(stack);
        if (name == null) {
            return 0;
        }
        Integer special = PocketConfig.ingotValues.get(name);
        return special != null ? special : PocketConfig.manaPerIngot;
    }
}
