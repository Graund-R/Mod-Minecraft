package pocketmod;

import net.minecraft.entity.player.EntityPlayer;

// Единый кошелёк маны игрока. Хранится в данных самого игрока, без верхнего предела.
public class Mana {

    private static final String KEY = "pocketmod_mana";

    public static double get(EntityPlayer player) {
        return player.getEntityData().getDouble(KEY);
    }

    public static void set(EntityPlayer player, double value) {
        player.getEntityData().setDouble(KEY, Math.max(0.0, value));
    }

    public static void add(EntityPlayer player, double amount) {
        set(player, get(player) + amount);
    }

    // Списывает ману, если хватает. Возвращает true, если списание прошло.
    public static boolean spend(EntityPlayer player, double amount) {
        double have = get(player);
        if (have < amount) {
            return false;
        }
        set(player, have - amount);
        return true;
    }
}
