package pocketmod;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraftforge.common.config.Configuration;

// Все числа, которые можно подкручивать, лежат в файле config/pocketmod.cfg
public class PocketConfig {

    public static int manaPerIngot = 10;
    public static final Map<String, Integer> ingotValues = new HashMap<String, Integer>();
    public static float deathManaLoss = 0.3f;
    public static int hudBarScale = 100;

    public static int entryCost = 10;
    public static int expandBaseCost = 4;
    public static float expandRingStep = 0.2f;
    public static String wallBlock = "minecraft:sea_lantern";

    public static void load(File file) {
        Configuration cfg = new Configuration(file);
        cfg.load();

        manaPerIngot = cfg.getInt("manaPerIngot", "mana", 10, 0, 1000000,
                "Mana given by one ingot (default for any ingot).");
        String[] overrides = cfg.getStringList("ingotValues", "mana",
                new String[] { "ingotIron=10", "ingotGold=25" },
                "Separate price for a kind of ingot, format: oreDictName=mana");
        ingotValues.clear();
        for (String s : overrides) {
            String[] kv = s.split("=");
            if (kv.length == 2) {
                try {
                    ingotValues.put(kv[0].trim(), Integer.parseInt(kv[1].trim()));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        deathManaLoss = cfg.getFloat("deathManaLoss", "mana", 0.3f, 0f, 1f,
                "Share of mana lost on death (0.3 = 30 percent).");
        hudBarScale = cfg.getInt("hudBarScale", "mana", 100, 1, 1000000,
                "Mana amount at which the bar on screen is full (the mana itself has no limit).");

        entryCost = cfg.getInt("entryCost", "pocket", 10, 0, 1000000,
                "Mana cost to enter the pocket dimension.");
        expandBaseCost = cfg.getInt("expandBaseCost", "pocket", 4, 1, 100000,
                "Ingots needed to open one wall block of the first ring.");
        expandRingStep = cfg.getFloat("expandRingStep", "pocket", 0.2f, 0f, 100f,
                "Price growth for each next ring (0.2 = plus 20 percent of base).");
        wallBlock = cfg.getString("wallBlock", "pocket", "minecraft:sea_lantern",
                "Block the walls are made of. Sea lantern glows, so the room is lit. Other blocks give no light.");

        if (cfg.hasChanged()) {
            cfg.save();
        }
    }

    public static IBlockState wallState() {
        Block b = Block.getBlockFromName(wallBlock);
        if (b == null || b == Blocks.AIR) {
            b = Blocks.SEA_LANTERN;
        }
        return b.getDefaultState();
    }

    // Цена одного блока стены в слитках; кольцо 1 это первая стена вокруг комнаты 5x5
    public static int expandCost(int ring) {
        double c = expandBaseCost * (1.0 + expandRingStep * (Math.max(1, ring) - 1));
        return Math.max(1, (int) Math.round(c));
    }
}
