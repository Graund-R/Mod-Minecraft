package pocketmod;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = PocketMod.MODID)
public class CommonEvents {

    // Стены карманного измерения ломать нельзя
    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent event) {
        World world = event.getWorld();
        if (world.isRemote || world.provider.getDimension() != PocketMod.DIM_ID) {
            return;
        }
        if (PocketData.get(world).walls.contains(event.getPos())) {
            event.setCanceled(true);
        }
    }

    // ПКМ слитками по блоку стены: слитки идут в оплату этого блока
    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        World world = event.getWorld();
        if (world.isRemote || world.provider.getDimension() != PocketMod.DIM_ID) {
            return;
        }
        PocketData data = PocketData.get(world);
        BlockPos pos = event.getPos();
        if (!data.walls.contains(pos)) {
            return;
        }
        EntityPlayer player = event.getEntityPlayer();
        ItemStack stack = player.getHeldItemMainhand();
        if (!Ingots.isIngot(stack)) {
            return;
        }

        // Слитки в руке и клик по стене: это оплата, больше ничего не происходит
        event.setCanceled(true);
        event.setCancellationResult(EnumActionResult.SUCCESS);
        if (event.getHand() != EnumHand.MAIN_HAND) {
            return;
        }
        if (!Pocket.isPayable(data, pos)) {
            return;
        }

        int cost = Pocket.cost(pos);
        int paid = data.paid.containsKey(pos) ? data.paid.get(pos) : 0;
        int give = Math.min(stack.getCount(), cost - paid);
        if (give <= 0) {
            return;
        }
        stack.shrink(give); // остаток слитков остаётся в руке
        paid += give;
        if (paid >= cost) {
            Pocket.open((WorldServer) world, data, pos);
        } else {
            data.paid.put(pos, paid);
            data.markDirty();
        }
    }

    // ПКМ слитками, когда клик ничего не активировал: вся пачка в руке превращается в ману
    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        World world = event.getWorld();
        if (world.isRemote) {
            return;
        }
        ItemStack stack = event.getItemStack();
        if (!Ingots.isIngot(stack)) {
            return;
        }
        EntityPlayer player = event.getEntityPlayer();

        // Если игрок целится в стену карманного измерения, это оплата блока, а не пополнение маны
        if (world.provider.getDimension() == PocketMod.DIM_ID) {
            RayTraceResult hit = player.rayTrace(5.0D, 1.0F);
            if (hit != null && hit.typeOfHit == RayTraceResult.Type.BLOCK
                    && PocketData.get(world).walls.contains(hit.getBlockPos())) {
                return;
            }
        }

        int gained = Ingots.manaValue(stack) * stack.getCount();
        Mana.add(player, gained);
        player.setHeldItem(event.getHand(), ItemStack.EMPTY);
        player.sendStatusMessage(new TextComponentTranslation("pocketmod.msg.mana_gained", gained), true);
    }

    // Смерть: теряется часть маны; если умер внутри карманного измерения, следующий вход бесплатный
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        EntityPlayer old = event.getOriginal();
        EntityPlayer now = event.getEntityPlayer();

        double mana = Mana.get(old);
        if (event.isWasDeath()) {
            mana = mana * (1.0 - PocketConfig.deathManaLoss);
            if (old.dimension == PocketMod.DIM_ID) {
                now.getEntityData().setBoolean("pocketmod_free_entry", true);
            }
        } else {
            // Возвращение из Энда и подобное: запомненное место возврата не теряем
            String[] keys = { "pocket_return_dim", "pocket_return_x", "pocket_return_y", "pocket_return_z" };
            for (String k : keys) {
                if (old.getEntityData().hasKey(k)) {
                    now.getEntityData().setTag(k, old.getEntityData().getTag(k));
                }
            }
        }
        if (old.getEntityData().getBoolean("pocketmod_free_entry")) {
            now.getEntityData().setBoolean("pocketmod_free_entry", true);
        }
        Mana.set(now, mana);
    }
}
