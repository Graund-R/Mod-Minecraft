package pocketmod;

import net.minecraft.block.BlockColored;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.util.ITeleporter;

public class PocketTeleporter implements ITeleporter {

    private final double x, y, z;

    public PocketTeleporter(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    // Ставит игрока в нужную точку после переноса
    @Override
    public void placeEntity(World world, Entity entity, float yaw) {
        entity.setLocationAndAngles(x, y, z, yaw, entity.rotationPitch);
        entity.motionX = 0;
        entity.motionY = 0;
        entity.motionZ = 0;
        entity.fallDistance = 0;
    }

    // Нажали K: если мы в карманном измерении, выходим, иначе заходим
    public static void toggle(EntityPlayerMP player) {
        MinecraftServer server = player.getServer();
        if (server == null) return;
        if (player.dimension == PocketMod.DIM_ID) {
            leave(player, server);
        } else {
            enter(player, server);
        }
    }

    private static void enter(EntityPlayerMP player, MinecraftServer server) {
        // Запоминаем, откуда ушёл
        NBTTagCompound data = player.getEntityData();
        data.setInteger("pocket_return_dim", player.dimension);
        data.setDouble("pocket_return_x", player.posX);
        data.setDouble("pocket_return_y", player.posY);
        data.setDouble("pocket_return_z", player.posZ);

        WorldServer pocket = server.getWorld(PocketMod.DIM_ID);
        buildBoxIfNeeded(pocket);

        // Центр комнаты, стоим на полу
        player.changeDimension(PocketMod.DIM_ID, new PocketTeleporter(2.5, 64, 2.5));
    }

    private static void leave(EntityPlayerMP player, MinecraftServer server) {
        NBTTagCompound data = player.getEntityData();
        int dim;
        double rx, ry, rz;

        if (data.hasKey("pocket_return_dim")) {
            dim = data.getInteger("pocket_return_dim");
            rx = data.getDouble("pocket_return_x");
            ry = data.getDouble("pocket_return_y");
            rz = data.getDouble("pocket_return_z");
        } else {
            // Запомненного места нет: отправляем на точку появления обычного мира
            WorldServer overworld = server.getWorld(0);
            BlockPos top = overworld.getTopSolidOrLiquidBlock(overworld.getSpawnPoint());
            dim = 0;
            rx = top.getX() + 0.5;
            ry = top.getY();
            rz = top.getZ() + 0.5;
        }

        player.changeDimension(dim, new PocketTeleporter(rx, ry, rz));
    }

    // Комната: внутри 5x5 и высота 3. Пол и стены белые, потолок светится (свет потом продумаем).
    private static void buildBoxIfNeeded(WorldServer w) {
        if (w.getBlockState(new BlockPos(2, 63, 2)).getBlock() != Blocks.AIR) {
            return; // уже построена
        }
        IBlockState white = Blocks.CONCRETE.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.WHITE);
        IBlockState lamp = Blocks.SEA_LANTERN.getDefaultState();

        for (int x = -1; x <= 5; x++) {
            for (int y = 63; y <= 67; y++) {
                for (int z = -1; z <= 5; z++) {
                    boolean shell = x == -1 || x == 5 || z == -1 || z == 5 || y == 63 || y == 67;
                    if (shell) {
                        w.setBlockState(new BlockPos(x, y, z), y == 67 ? lamp : white, 2);
                    }
                }
            }
        }
    }
}
