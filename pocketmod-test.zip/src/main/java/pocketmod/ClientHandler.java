package pocketmod;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class ClientHandler {

    private static KeyBinding pocketKey;

    public static void register() {
        pocketKey = new KeyBinding("key.pocketmod.pocket", Keyboard.KEY_K, "key.categories.pocketmod");
        ClientRegistry.registerKeyBinding(pocketKey);
        MinecraftForge.EVENT_BUS.register(new ClientHandler());
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (!pocketKey.isPressed()) return;

        Minecraft mc = Minecraft.getMinecraft();
        // Мод для одиночной игры: общаемся со встроенным сервером напрямую
        if (mc.player == null || !mc.isIntegratedServerRunning()) return;

        IntegratedServer server = mc.getIntegratedServer();
        EntityPlayerMP player = server.getPlayerList().getPlayerByUUID(mc.player.getUniqueID());
        if (player != null) {
            server.addScheduledTask(() -> PocketTeleporter.toggle(player));
        }
    }
}
