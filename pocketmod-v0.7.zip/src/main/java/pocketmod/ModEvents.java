package pocketmod;

import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingSetAttackTargetEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;

@Mod.EventBusSubscriber(modid = PocketMod.MODID)
public class ModEvents {

    /** Невидимость (замечают только вплотную) и «Тишина» после телепорта. */
    @SubscribeEvent
    public static void onTarget(LivingSetAttackTargetEvent e) {
        if (!(e.getEntityLiving() instanceof EntityLiving)) return;
        EntityLivingBase t = e.getTarget();
        if (!(t instanceof EntityPlayerMP)) return;
        EntityLiving mob = (EntityLiving) e.getEntityLiving();
        EntityPlayerMP p = (EntityPlayerMP) t;
        if (Abilities.isSilent(p)) {
            mob.setAttackTarget(null);
            return;
        }
        if (Abilities.isInvisible(p) && !Abilities.isInvisBroken(p) && mob.getDistance(p) > PocketConfig.invisNoticeRange) {
            mob.setAttackTarget(null);
        }
    }

    /** Удар игроком сбрасывает невидимость на несколько секунд. */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent e) {
        if (e.getSource().getTrueSource() instanceof EntityPlayerMP) {
            Abilities.breakInvisibility((EntityPlayerMP) e.getSource().getTrueSource());
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.player instanceof EntityPlayerMP) {
            Spector.recoverOnLogin((EntityPlayerMP) e.player);
        }
    }
}
