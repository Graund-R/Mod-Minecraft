package pocketmod;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraftforge.common.config.Configuration;

public class PocketConfig {

    public static int valueIron = 10;
    public static int valueGold = 30;
    public static int valueDiamond = 100;
    public static int valueEmerald = 80;
    public static int manaPerIngot = 10;
    public static final Map<String, Integer> ingotValues = new HashMap<String, Integer>();
    public static float deathManaLoss = 0.30f;
    /** Минимальная длина шкалы маны (пока ничего не открыто). */
    public static int hudBarScale = 100;

    public static int holdMs = 400;

    public static int creditMin = 100;
    public static int creditMax = 2000;
    public static float creditInterest = 0.20f;
    public static int creditDurationSec = 1800;
    public static float creditPenaltyFactor = 0.25f;
    public static boolean creditWarnings = true;

    public static int entryCost = 10;
    public static float entryRingStep = 0.2f;
    public static float pocketDiscountL2 = 0.25f;
    public static int mobResetRadius = 40;
    public static int expandBaseCost = 4;
    public static float expandRingStep = 0.2f;
    public static String wallBlock = "minecraft:concrete";

    public static int teleportBaseRange = 50;
    public static int teleportRange2 = 100;
    public static int teleportRange3 = 200;
    public static float teleportCostPerBlock = 0.4f;

    // Тотемы
    public static int totemCreateCost = 30;
    public static int totemDeleteCost = 10;
    public static int totemTeleportBase = 20;
    public static float totemTeleportPerBlock = 0.02f;
    public static int totemDimensionCost = 100;
    public static int totemSlots1 = 4;
    public static int totemSlots2 = 8;
    public static int totemSlots3 = 16;
    public static float totemDiscount2 = 0.25f;
    public static float totemDiscount3 = 0.5f;
    public static int totemMarkerRange = 48;
    public static int[] totemPalette = { 0xFF6B6B, 0xFFD93D, 0x6BCB77, 0x4D96FF, 0xC77DFF, 0xFF9F45 };


    // Невидимость / приманка / тишина
    public static int decoyCost = 40;
    public static int decoyMaxSec = 30;
    public static int invisHitBreakTicks = 100;
    public static double invisNoticeRange = 3.0;
    public static int silenceMinLevel = 2;
    public static int silenceTicks = 50;

    // Спектор
    public static float spectorBaseDrain = 0.6f;
    public static float spectorPerBlock = 0.03f;
    public static float phaseBase = 20f;
    public static float phasePerBlock = 0.5f;

    // Тепловизор
    public static int thermalRadius1 = 24;
    public static int thermalRadius2 = 40;
    public static float thermalDrain1 = 1.2f;
    public static float thermalDrain2 = 0.8f;

    // Щит
    public static float shieldManaPerDamage = 15f;
    public static float shieldL2Factor = 0.7f;

    // Полёт
    public static float flightDrain = 1.5f;
    public static int[] flightHeight = { 32, 64, 128 };
    public static float[] flightSpeed = { 0.04f, 0.055f, 0.075f };
    public static int flightGraceSec = 5;

    // Тело: сердца, скорость, сила, огнестойкость, дыхание
    public static int[] bodyPermCost = { 300, 500, 600, 150, 150 };
    public static double[] bodyRentPerSec = { 0.8, 1.0, 1.2, 0.3, 0.3 };
    public static int heartsMaxBuys = 5;
    public static int heartsRent = 2;

    // Лутка
    public static int[] lootStakes = { 50, 150, 400 };
    public static int lootPity = 6;

    public static boolean hidePotionIcons = true;

    /** Понижать тон звуков при замедлении (выключено, пока не выяснили причину вылета). */
    public static boolean slowSound = false;

    public static void load(File file) {
        Configuration cfg = new Configuration(file);
        cfg.load();

        valueIron = cfg.getInt("valueIron", "mana", 10, 0, 1000000, "Mana for one iron ingot");
        valueGold = cfg.getInt("valueGold", "mana", 30, 0, 1000000, "Mana for one gold ingot");
        valueDiamond = cfg.getInt("valueDiamond", "mana", 100, 0, 1000000, "Mana for one diamond");
        valueEmerald = cfg.getInt("valueEmerald", "mana", 80, 0, 1000000, "Mana for one emerald");
        manaPerIngot = cfg.getInt("manaPerIngot", "mana", 10, 0, 1000000, "Fallback for other ingots");
        deathManaLoss = cfg.getFloat("deathManaLoss", "mana", 0.30f, 0f, 1f, "Mana lost on death");
        hudBarScale = cfg.getInt("hudBarScale", "mana", 100, 1, 1000000, "Minimum mana bar length (grows with the most expensive unlocked ability)");

        String[] overrides = cfg.getStringList("ingotValues", "mana",
                new String[] { "ingotIron=10", "ingotGold=30" },
                "oreDictName=mana overrides");
        ingotValues.clear();
        for (String s : overrides) {
            String[] kv = s.split("=");
            if (kv.length == 2) {
                try {
                    ingotValues.put(kv[0].trim(), Integer.parseInt(kv[1].trim()));
                } catch (NumberFormatException ignored) {
                }
            }
        }

        holdMs = cfg.getInt("holdMs", "controls", 400, 100, 2000, "Milliseconds for hold");

        creditMin = cfg.getInt("creditMin", "credit", 100, 1, 1000000, "Min credit");
        creditMax = cfg.getInt("creditMax", "credit", 2000, 1, 1000000, "Max credit");
        creditInterest = cfg.getFloat("creditInterest", "credit", 0.20f, 0f, 10f, "Interest");
        creditDurationSec = cfg.getInt("creditDurationSec", "credit", 1800, 60, 86400, "Duration seconds (game time, pause not counted)");
        creditPenaltyFactor = cfg.getFloat("creditPenaltyFactor", "credit", 0.25f, 0f, 10f, "Penalty factor");
        creditWarnings = cfg.getBoolean("creditWarnings", "credit", true, "Warn 5 and 1 minute before the credit is due");

        entryCost = cfg.getInt("entryCost", "pocket", 10, 0, 1000000, "Base entry cost");
        entryRingStep = cfg.getFloat("entryRingStep", "pocket", 0.2f, 0f, 100f, "Entry cost growth per expanded ring");
        pocketDiscountL2 = cfg.getFloat("pocketDiscountL2", "pocket", 0.25f, 0f, 1f, "Entry discount at pocket level 2");
        mobResetRadius = cfg.getInt("mobResetRadius", "pocket", 40, 0, 128, "Mobs within this radius lose their target on enter/exit");
        expandBaseCost = cfg.getInt("expandBaseCost", "pocket", 4, 1, 100000, "Base expand cost in iron units");
        expandRingStep = cfg.getFloat("expandRingStep", "pocket", 0.2f, 0f, 100f, "Ring cost growth");
        wallBlock = cfg.getString("wallBlock", "pocket", "minecraft:concrete", "Wall block (white concrete = marble look)");

        teleportBaseRange = cfg.getInt("teleportBaseRange", "abilities", 50, 5, 500, "Teleport range, level 1");
        teleportRange2 = cfg.getInt("teleportRange2", "abilities", 100, 5, 1000, "Teleport range, level 2");
        teleportRange3 = cfg.getInt("teleportRange3", "abilities", 200, 5, 2000, "Teleport range, level 3");
        teleportCostPerBlock = cfg.getFloat("teleportCostPerBlock", "abilities", 0.4f, 0f, 1000f, "Mana per block of teleport distance");

        totemCreateCost = cfg.getInt("totemCreateCost", "totems", 30, 0, 1000000, "Mana to create a totem");
        totemDeleteCost = cfg.getInt("totemDeleteCost", "totems", 10, 0, 1000000, "Mana to delete a totem");
        totemTeleportBase = cfg.getInt("totemTeleportBase", "totems", 20, 0, 1000000, "Base mana for a totem teleport");
        totemTeleportPerBlock = cfg.getFloat("totemTeleportPerBlock", "totems", 0.02f, 0f, 1000f, "Mana per block of distance (same dimension)");
        totemDimensionCost = cfg.getInt("totemDimensionCost", "totems", 100, 0, 1000000, "Extra mana when changing dimension");
        totemSlots1 = cfg.getInt("totemSlots1", "totems", 4, 1, 64, "Slots at totem level 1");
        totemSlots2 = cfg.getInt("totemSlots2", "totems", 8, 1, 64, "Slots at totem level 2");
        totemSlots3 = cfg.getInt("totemSlots3", "totems", 16, 1, 64, "Slots at totem level 3");
        totemDiscount2 = cfg.getFloat("totemDiscount2", "totems", 0.25f, 0f, 1f, "Teleport price discount at level 2");
        totemDiscount3 = cfg.getFloat("totemDiscount3", "totems", 0.5f, 0f, 1f, "Teleport price discount at level 3");
        totemMarkerRange = cfg.getInt("totemMarkerRange", "totems", 48, 8, 128, "Marker draw distance");
        String[] cols = cfg.getStringList("totemColors", "totems",
                new String[] { "FF6B6B", "FFD93D", "6BCB77", "4D96FF", "C77DFF", "FF9F45" },
                "Marker colors (RRGGBB), used in list order");
        int[] parsed = new int[cols.length];
        int n = 0;
        for (String c : cols) {
            try {
                parsed[n] = Integer.parseInt(c.trim().replace("#", ""), 16) & 0xFFFFFF;
                n++;
            } catch (NumberFormatException ignored) {
            }
        }
        if (n > 0) {
            totemPalette = java.util.Arrays.copyOf(parsed, n);
        }


        decoyCost = cfg.getInt("decoyCost", "invisibility", 40, 0, 1000000, "Mana to create the decoy clone");
        decoyMaxSec = cfg.getInt("decoyMaxSec", "invisibility", 30, 1, 600, "Decoy lifetime, seconds");
        invisHitBreakTicks = cfg.getInt("invisHitBreakTicks", "invisibility", 100, 0, 6000, "Invisibility is broken this many ticks after you hit something");
        invisNoticeRange = cfg.getFloat("invisNoticeRange", "invisibility", 3.0f, 0f, 32f, "Mobs still notice an invisible player this close");
        silenceMinLevel = cfg.getInt("silenceMinLevel", "abilities", 2, 1, 3, "Teleport level that gives Silence");
        silenceTicks = cfg.getInt("silenceTicks", "abilities", 50, 0, 1200, "Ticks mobs ignore you after teleport (Silence)");

        spectorBaseDrain = cfg.getFloat("spectorBaseDrain", "spector", 0.6f, 0f, 1000f, "Mana/sec in spirit form");
        spectorPerBlock = cfg.getFloat("spectorPerBlock", "spector", 0.03f, 0f, 1000f, "Extra mana/sec per block from body");
        phaseBase = cfg.getFloat("phaseBase", "spector", 20f, 0f, 100000f, "Phase step base cost");
        phasePerBlock = cfg.getFloat("phasePerBlock", "spector", 0.5f, 0f, 1000f, "Phase step cost per block");

        thermalRadius1 = cfg.getInt("thermalRadius1", "thermal", 24, 4, 128, "Radius level 1");
        thermalRadius2 = cfg.getInt("thermalRadius2", "thermal", 40, 4, 128, "Radius level 2");
        thermalDrain1 = cfg.getFloat("thermalDrain1", "thermal", 1.2f, 0f, 1000f, "Mana/sec level 1");
        thermalDrain2 = cfg.getFloat("thermalDrain2", "thermal", 0.8f, 0f, 1000f, "Mana/sec level 2");

        shieldManaPerDamage = cfg.getFloat("shieldManaPerDamage", "shield", 15f, 0f, 10000f, "Mana per 1 damage");
        shieldL2Factor = cfg.getFloat("shieldL2Factor", "shield", 0.7f, 0.01f, 1f, "Cost factor at shield level 2");

        flightDrain = cfg.getFloat("flightDrain", "flight", 1.5f, 0f, 1000f, "Mana/sec while flying");
        flightGraceSec = cfg.getInt("flightGraceSec", "flight", 5, 0, 60, "Soft hover seconds at zero mana");
        int[] fh = cfg.get("flight", "heights", new int[] { 32, 64, 128 }, "Max height above ground by level").getIntList();
        if (fh.length >= 3) flightHeight = fh;
        double[] fs = cfg.get("flight", "speeds", new double[] { 0.04, 0.055, 0.075 }, "Fly speed by level (vanilla creative 0.05)").getDoubleList();
        if (fs.length >= 3) flightSpeed = new float[] { (float) fs[0], (float) fs[1], (float) fs[2] };

        int[] bp = cfg.get("body", "permCosts", new int[] { 300, 500, 600, 150, 150 }, "Permanent price: hearts, speed, strength, fire resistance, water breathing").getIntList();
        if (bp.length >= 5) bodyPermCost = bp;
        double[] br = cfg.get("body", "rentPerSec", new double[] { 0.8, 1.0, 1.2, 0.3, 0.3 }, "Rent mana/sec in the same order").getDoubleList();
        if (br.length >= 5) bodyRentPerSec = br;
        heartsMaxBuys = cfg.getInt("heartsMaxBuys", "body", 5, 1, 50, "Max permanent heart purchases (+1 heart each)");
        heartsRent = cfg.getInt("heartsRent", "body", 2, 1, 50, "Extra hearts while renting");

        int[] ls = cfg.get("loot", "stakes", new int[] { 50, 150, 400 }, "Spin prices (3 tiers)").getIntList();
        if (ls.length >= 3) lootStakes = ls;
        lootPity = cfg.getInt("lootPity", "loot", 6, 1, 100, "Guaranteed win after this many bad results");

        hidePotionIcons = cfg.getBoolean("hidePotionIcons", "hud", true, "Hide vanilla potion icons (only the mana bar on screen)");

        slowSound = cfg.getBoolean("slowSound", "abilities", false, "Lower the pitch of sounds while time is slowed");

        if (cfg.hasChanged()) {
            cfg.save();
        }
    }

    public static int totemColor(int index) {
        return totemPalette[Math.abs(index) % totemPalette.length];
    }

    public static IBlockState wallState() {
        Block b = Block.getBlockFromName(wallBlock);
        if (b == null || b == Blocks.AIR) {
            b = Blocks.CONCRETE;
        }
        if (b == Blocks.CONCRETE) {
            return b.getStateFromMeta(0);
        }
        return b.getDefaultState();
    }

    public static int expandCost(int ring) {
        double c = expandBaseCost * (1.0 + expandRingStep * (Math.max(1, ring) - 1));
        return Math.max(1, (int) Math.round(c));
    }
}
