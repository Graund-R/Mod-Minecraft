package pocketmod;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Полёт (двойной пробел): как в креативе, но за ману, с потолком высоты и скорости. */
@Mod.EventBusSubscriber(modid = PocketMod.MODID)
public class Flight {

    private static final String ARMED = "pm_flight";
    private static final String GRACE = "pm_flight_grace";
    private static final String NOFALL = "pm_flight_nofall";

    public static boolean isArmed(EntityPlayer p) {
        return p.getEntityData().getBoolean(ARMED);
    }

    private static int level(EntityPlayer p) {
        return Math.max(1, Math.min(3, AbilityStorage.getLevel(p, AbilityType.FLIGHT)));
    }

    public static double drainPerSec(EntityPlayer p) {
        return PocketConfig.flightDrain * Mana.getPriceMultiplier(p);
    }

    public static void start(EntityPlayerMP p) {
        if (isArmed(p) || p.isCreative() || p.isSpectator()) return;
        if (!AbilityStorage.isUnlocked(p, AbilityType.FLIGHT)) return; // двойной пробел без покупки молчит
        if (Spector.isActive(p)) {
            p.sendStatusMessage(new TextComponentTranslation("pocketmod.msg.spector_flight"), true);
            return;
        }
        if (Mana.get(p) < drainPerSec(p)) {
            p.sendStatusMessage(new TextComponentTranslation("pocketmod.msg.no_mana", (int) Math.ceil(drainPerSec(p))), true);
            return;
        }
        p.getEntityData().setBoolean(ARMED, true);
        p.getEntityData().setInteger(GRACE, 0);
        p.capabilities.allowFlying = true;
        p.capabilities.isFlying = true;
        p.capabilities.setFlySpeed(PocketConfig.flightSpeed[level(p) - 1]);
        p.sendPlayerAbilities();
    }

    public static void stop(EntityPlayerMP p) {
        if (!isArmed(p)) return;
        disarm(p);
    }

    private static void disarm(EntityPlayerMP p) {
        p.getEntityData().setBoolean(ARMED, false);
        p.getEntityData().setInteger(GRACE, 0);
        if (!p.isCreative() && !p.isSpectator()) {
            p.capabilities.allowFlying = false;
            p.capabilities.isFlying = false;
            p.capabilities.setFlySpeed(0.05F);
            p.sendPlayerAbilities();
        }
    }

    public static void tick(EntityPlayerMP p) {
        if (p.getEntityData().getBoolean(NOFALL) && p.onGround) {
            p.getEntityData().setBoolean(NOFALL, false);
        }
        if (!isArmed(p)) return;
        if (p.isCreative() || p.isSpectator()) {
            p.getEntityData().setBoolean(ARMED, false);
            return;
        }
        int grace = p.getEntityData().getInteger(GRACE);
        if (grace > 0) {
            // мягкое парение без расхода
            p.fallDistance = 0f;
            p.getEntityData().setInteger(GRACE, grace - 1);
            if (grace - 1 == 0) {
                p.getEntityData().setBoolean(NOFALL, true);
                disarm(p);
            }
            return;
        }
        if (!p.capabilities.isFlying) {
            if (p.onGround) disarm(p);
            return;
        }
        if (!Mana.spend(p, drainPerSec(p) / 20.0)) {
            p.getEntityData().setInteger(GRACE, Math.max(1, PocketConfig.flightGraceSec * 20));
            p.sendStatusMessage(new TextComponentTranslation("pocketmod.msg.flight_empty"), true);
            return;
        }
        p.fallDistance = 0f;
        int ground = p.world.getHeight(new BlockPos(p.posX, p.posY, p.posZ)).getY();
        double cap = ground + PocketConfig.flightHeight[level(p) - 1];
        if (p.posY > cap) {
            p.motionY = Math.min(0.0, p.motionY);
            p.connection.setPlayerLocation(p.posX, cap, p.posZ, p.rotationYaw, p.rotationPitch);
        }
        WorldServer ws = (WorldServer) p.world;
        if (p.ticksExisted % 4 == 0) {
            ws.spawnParticle(EnumParticleTypes.CLOUD, p.posX, p.posY + 0.1, p.posZ, 2, 0.25, 0.02, 0.25, 0.01);
        }
        if (p.ticksExisted % 60 == 0) {
            ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ITEM_ELYTRA_FLYING, SoundCategory.PLAYERS, 0.15F, 1.2F);
        }
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent e) {
        if (e.getEntityLiving() instanceof EntityPlayerMP) {
            EntityPlayerMP p = (EntityPlayerMP) e.getEntityLiving();
            if (p.getEntityData().getBoolean(NOFALL)) {
                e.setCanceled(true);
            }
        }
    }
}
