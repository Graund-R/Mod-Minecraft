package pocketmod;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.text.TextComponentTranslation;

/** Тепловизор: серверная часть (переключатель и расход). Рисуется на клиенте. */
public class Thermal {

    private static final String KEY = "pm_thermal";

    public static boolean isOn(EntityPlayer p) {
        return p.getEntityData().getBoolean(KEY);
    }

    public static int radius(EntityPlayer p) {
        return AbilityStorage.getLevel(p, AbilityType.THERMAL) >= 2 ? PocketConfig.thermalRadius2 : PocketConfig.thermalRadius1;
    }

    public static double drainPerSec(EntityPlayer p) {
        double d = AbilityStorage.getLevel(p, AbilityType.THERMAL) >= 2 ? PocketConfig.thermalDrain2 : PocketConfig.thermalDrain1;
        return d * Mana.getPriceMultiplier(p);
    }

    public static void toggle(EntityPlayerMP p) {
        if (!AbilityStorage.isUnlocked(p, AbilityType.THERMAL)) {
            p.sendStatusMessage(new TextComponentTranslation("pocketmod.msg.need_shop"), true);
            return;
        }
        boolean now = !isOn(p);
        if (now && Mana.get(p) < drainPerSec(p)) {
            p.sendStatusMessage(new TextComponentTranslation("pocketmod.msg.no_mana", (int) Math.ceil(drainPerSec(p))), true);
            return;
        }
        p.getEntityData().setBoolean(KEY, now);
    }

    public static void tick(EntityPlayerMP p) {
        if (!isOn(p)) return;
        if (!Mana.spend(p, drainPerSec(p) / 20.0)) {
            p.getEntityData().setBoolean(KEY, false);
            p.sendStatusMessage(new TextComponentTranslation("pocketmod.msg.thermal_off"), true);
        }
    }
}
